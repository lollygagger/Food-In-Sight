import json
import boto3
from base64 import b64decode
import re

def is_base64(sb):
    # Check if the string is a valid Base64 string
    try:
        if isinstance(sb, str):
            sb_bytes = bytes(sb, 'utf-8')
        elif isinstance(sb, bytes):
            sb_bytes = sb
        else:
            return False
        return b64decode(sb_bytes, validate=True) is not None
    except Exception:
        return False

def lambda_handler(event, context):
    if 'body' not in event:
        return {
            "statusCode": 400,
            "body": json.dumps("Request is missing 'body'")
        }

    try:
        body = json.loads(event['body'])
    except json.JSONDecodeError:
        return {
            "statusCode": 400,
            "body": json.dumps("Invalid JSON format in 'body'")
        }

    image_data = body.get("image_data")
    if not image_data:
        return {
            "statusCode": 400,
            "body": json.dumps("Image data is missing in 'body'")
        }

    # Validate if image_data is a properly formatted Base64 string
    if not is_base64(image_data):
        return {
            "statusCode": 400,
            "body": json.dumps("Invalid Base64 format for image data")
        }

    try:
        image_bytes = b64decode(image_data)
    except Exception as e:
        return {
            "statusCode": 400,
            "body": json.dumps(f"Error decoding Base64 image data: {str(e)}")
        }

    rekognition = boto3.client('rekognition')
    response = rekognition.detect_labels(
        Image={'Bytes': image_bytes},
        MaxLabels=10
    )

    return {
        "statusCode": 200,
        "body": json.dumps(response)
    }
