import json
import boto3

def lambda_handler(event, context):
    rekognition = boto3.client('rekognition')
    
    # Get the S3 image URL from the event input
    s3_url = event['image_url']
    bucket_name = s3_url.split("/")[2]
    key = "/".join(s3_url.split("/")[3:])
    
    # Call Rekognition to detect labels
    response = rekognition.detect_labels(
        Image={
            'S3Object': {
                'Bucket': bucket_name,
                'Name': key
            }
        },
        MaxLabels=10,
        MinConfidence=70
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'rekognitionResult': response['Labels']
        })
    }
