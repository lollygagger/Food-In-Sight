import json
import boto3

def lambda_handler(event, context):
    rekognition = boto3.client('rekognition')
    
    # Get the S3 image URL from the event input
    s3_url = event['image_url']
    bucket_name = s3_url.split("/")[2]
    key = "/".join(s3_url.split("/")[3:])
    
    # Call Rekognition to detect labels
    response = rekognition.detect_labels(
        Image={
            'S3Object': {
                'Bucket': bucket_name,
                'Name': key
            }
        },
        MaxLabels=10,
        MinConfidence=70
    )
    
    # Prepare input for Step Function
    step_function_input = {
        'image_labels': response['Labels'],  # Labels from Rekognition
        's3_bucket': bucket_name,
        's3_key': key
    }
    
    # Trigger Step Function (commenting out actual processing for now)
    # step_functions_client = boto3.client('stepfunctions')
    # step_response = step_functions_client.start_execution(
    #     stateMachineArn=step_function_arn,
    #     input=json.dumps(step_function_input)
    # )

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Image processed successfully and Step Function triggered.',
            'rekognition_labels': response['Labels'],  # Return Rekognition labels in the response
            # 'step_function_execution_arn': step_response['executionArn']  # Commented out, as we aren't processing Step Function response yet
        })
    }
