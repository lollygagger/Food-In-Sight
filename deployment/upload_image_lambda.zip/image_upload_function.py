import boto3
import json
import os

# Initialize clients
s3 = boto3.client('s3')
stepfunctions = boto3.client('stepfunctions')

def lambda_handler(event, context):
    # Parse incoming event (assumes it's an API Gateway event)
    bucket_name = event['bucket_name']
    file_name = event['file_name']
    
    # Upload the image to S3
    s3.upload_file(file_name, bucket_name, file_name)
    
    # Build the S3 URL
    image_url = f"s3://{bucket_name}/{file_name}"

    # Step Function ARN
    step_function_arn = os.environ['STEP_FUNCTION_ARN']

    # Trigger Step Function with image URL
    response = stepfunctions.start_execution(
        stateMachineArn=step_function_arn,
        name=f"Execution-{context.aws_request_id}",
        input=json.dumps({
            "image_url": image_url
        })
    )

    # Return response (optional, for API Gateway)
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Image uploaded and Step Function triggered.",
            "executionArn": response['executionArn']
        })
    }
