import json
import boto3
import uuid

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Assuming the image is sent in the body of the POST request
    image_data = event['body']  # Base64-encoded image data

    bucket_name = "imagebucketuniquename123123089658970"
    image_key = f"images/{uuid.uuid4()}.jpg"
    
    # Decode the base64-encoded image and upload to S3
    image_bytes = base64.b64decode(image_data)

    s3_client.put_object(Bucket=bucket_name, Key=image_key, Body=image_bytes, ContentType='image/jpeg')

    # Return the S3 URL
    image_url = f"https://{bucket_name}.s3.amazonaws.com/{image_key}"
    
    return {
        "statusCode": 200,
        "body": json.dumps({"image_url": image_url})
    }
